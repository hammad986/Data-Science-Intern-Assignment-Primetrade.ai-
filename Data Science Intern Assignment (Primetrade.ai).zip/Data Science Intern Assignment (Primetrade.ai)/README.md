# Trader Performance vs Market Sentiment Analysis

## Objective
This project analyzes how market sentiment (Fear vs Greed) influences trader behavior and trading performance. The goal is to uncover patterns that can inform smarter trading strategies.

---

## Datasets Used

| Dataset | Description |
|--------|-------------|
| Bitcoin Fear & Greed Index | Daily market sentiment classification |
| Historical Trader Data | Trade-level execution and PnL data |

---

## Methodology

1. **Data Cleaning**
   - Removed missing timestamps and PnL values
   - Standardized date formats

2. **Time Alignment**
   - Converted trade timestamps to daily level
   - Merged sentiment data with trade data on date

3. **Feature Engineering**
   - Win rate (profitability)
   - Average trade size
   - Trades per day
   - Long/short ratio

4. **Daily Aggregation**
   - Computed trader-level daily metrics

5. **Analysis**
   - Compared performance between Fear vs Greed periods
   - Studied behavior changes
   - Segmented traders by trade size and frequency

---

## Key Findings

- Traders increase trade size during Greed sentiment.
- Win rates decline during Fear periods.
- Frequent traders tend to overtrade during volatile conditions.
- Larger position sizes increase risk exposure.

---

## Strategy Recommendations

- Reduce trade size during Fear sentiment.
- Avoid overtrading in volatile markets.
- Increase exposure only when win rates show improvement.
- Monitor trade frequency to prevent performance degradation.

---

## Bonus Work

- Built a simple machine learning model to predict trade profitability.
- Segmented traders into behavioral groups.

---

## How to Run

```bash
pip install -r requirements.txt
jupyter notebook main.ipynb
